# VIRTEX
Virtex for Whatsapp

apt update && apt upgrade

apt install git

apt install curl

apt install figlet

apt install ruby

gem install lolcat

git clone https://github.com/yamz-11/VIRTEX

cd VIRTEX

chmod +x virtex.sh

sh virtex.sh
